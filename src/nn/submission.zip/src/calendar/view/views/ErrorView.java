package calendar.view.views;

public class ErrorView {
  public static void displayError(String message) {
    System.out.println("Error: " + message);
  }
}
